from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.forms import UserCreationForm
from django.views.generic import CreateView, UpdateView, DeleteView
from .models import FoodType, Food, Like, Comment
from .forms import CommentForm

import os


# Foydalanuvchini ro'yxatdan o'tkazish
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


# Bosh sahifa - barcha taom turlari va taomlarni ko'rsatish
def home(request):
    food_types = FoodType.objects.all()
    foods = Food.objects.all()
    return render(request, 'fastfood_app/home.html', {'food_types': food_types, 'foods': foods})


# Taomni to'liq ko'rish, izohlar va layklar
def food_detail(request, pk):
    food = get_object_or_404(Food, pk=pk)
    comments = food.comments.all()
    like_count = food.likes.count()
    is_liked = food.likes.filter(user=request.user).exists() if request.user.is_authenticated else False

    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.food = food
            comment.user = request.user
            comment.save()
            return redirect('food_detail', pk=food.pk)
    else:
        comment_form = CommentForm()

    return render(request, 'fastfood_app/food_detail.html', {
        'food': food,
        'comments': comments,
        'like_count': like_count,
        'is_liked': is_liked,
        'comment_form': comment_form,
    })


# Layk qo'shish yoki o'chirish
@login_required
def like_food(request, pk):
    food = get_object_or_404(Food, pk=pk)
    like, created = Like.objects.get_or_create(user=request.user, food=food)
    if not created:
        like.delete()
    return redirect('food_detail', pk=pk)


# Media fayllarni qaytarish
def media(request, path):
    file_path = os.path.join(settings.MEDIA_ROOT, path)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            return HttpResponse(file.read(), content_type='application/octet-stream')
    else:
        return HttpResponse(status=404)


# Taom qo'shish
@permission_required('fastfood_app.add_food')
def add_food(request):
    if request.method == "POST":
        form = FoodForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Taom muvaffaqiyatli qo\'shildi!')
            return redirect('home')
    else:
        form = FoodForm()
    return render(request, 'fastfood_app/add_food.html', {'form': form})


# Taomni yangilash
@permission_required('fastfood_app.change_food')
def update_food(request, pk):
    food = get_object_or_404(Food, pk=pk)
    if request.method == "POST":
        form = FoodForm(request.POST, instance=food)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = FoodForm(instance=food)
    return render(request, 'fastfood_app/update_food.html', {'form': form})


# Taomni o'chirish
@permission_required('fastfood_app.delete_food')
def delete_food(request, pk):
    food = get_object_or_404(Food, pk=pk)
    food.delete()
    return redirect('home')
