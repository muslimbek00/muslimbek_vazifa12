from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.register, name='register'),
    path('', views.home, name='home'),
    path('food/<int:pk>/', views.food_detail, name='food_detail'),
    path('add_food/', views.add_food, name='add_food'),
    path('update_food/<int:pk>/', views.update_food, name='update_food'),
    path('delete_food/<int:pk>/', views.delete_food, name='delete_food'),
    path('food/<int:pk>/like/', views.like_food, name='like_food'),  # Bu qator to'g'ri
]
